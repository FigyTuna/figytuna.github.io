
A Game by Ryan.

------------------------------

Double click "A Game by Ryan.jar" to play.
Moving any files may cause the game to stop working.

------------------------------

If double clicking "A Game by Ryan.jar" doesn't work then try these things (windows):

	1. Hold the start key and press "r".
	2. Type in "cmd" and press enter.
	3. If the folder "A Game by Ryan" is on the dekstop, type "cd desktop". (If it's not, navigate to where it is.)
	4. Type "cd A Game by Ryan".
	5. Type "cd game".
	6. Type "java -jar game.jar".

If the game still hasn't started then update java and try again.

------------------------------

Thanks for playing.